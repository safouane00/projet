#ifndef ADMIN_PANAL_H
#define ADMIN_PANAL_H


class admin_panal
{
public:
    admin_panal();
};

#endif // ADMIN_PANAL_H
