
#include "admin_panal.h"

admin_panal::admin_panal()
{

}
