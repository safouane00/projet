#include "dialog2.h"
#include "animaux.h"
#include "delegate.h"
#include "nourriture.h"
#include "ui_dialog2.h"
#include <QMessageBox>
#include <QRegExpValidator>
#define email_rx "^[0-9a-zA-Z]+([0-9a-zA-Z]*[-._+])*[0-9a-zA-Z]+@[0-9a-zA-Z]+([-.][0-9a-zA-Z]+)*([0-9a-zA-Z]*[.])[a-zA-Z]{2,6}$"
#define nom_rx "^([A-Za-z])+$"


Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);
    animaux a;
    ui->tableView->setModel(a.afficher(this));
    ui->comboBox_2->addItem("trie par prix");
    ui->comboBox_2->addItem("trie par masse");
    ui->comboBox->setModel(a.afficher_id());
    ui->label_11->setText( ui->comboBox->currentText());
    ui->lineEdit_2->setValidator( new QIntValidator(0, 99999999, this) );
    ui->lineEdit_7->setValidator( new QIntValidator(0, 99999999, this) );
    ui->lineEdit_5->setValidator( new QIntValidator(0, 99999999, this) );
    ui->lineEdit_6->setValidator( new QIntValidator(0, 99999999, this) );
    ui->lineEdit_10->setValidator( new QIntValidator(0, 99999999, this) );
    QRegExp nom(nom_rx);
    QRegExpValidator *valid_n=new QRegExpValidator(nom,this);

   ui->lineEdit_3->setValidator(valid_n);
   ui->lineEdit_9->setValidator(valid_n);

       ui->label_12->setText( ui->comboBox_2->currentText());
       nourriture b;
       ui->tableView_2->setModel(b.afficher(this));

       ui->comboBox_3->setModel(b.afficher_id());
       ui->label_16->setText( ui->comboBox_3->currentText());
}

Dialog2::~Dialog2()
{
    delete ui;
}

void Dialog2::on_pushButton_clicked()
{
    int a= ui->lineEdit_2->text().toInt();
    int d= ui->lineEdit_6->text().toInt();

    int c= ui->lineEdit_7->text().toInt();
    QString b= ui->lineEdit_3->text();


    animaux o(a,b,c,d);
    if(o.ajouter()){

        QMessageBox::information(nullptr, QObject::tr("ajout successful"),
                    QObject::tr("ajout successful.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}
    refresh();
}
void Dialog2::refresh(){
    animaux a;
    ui->tableView->setModel(a.afficher(this));

    ui->comboBox->setModel(a.afficher_id());
    ui->label_11->setText( ui->comboBox->currentText());
       ui->label_12->setText( ui->comboBox_2->currentText());
       nourriture b;
       ui->tableView_2->setModel(b.afficher(this));

       ui->comboBox_3->setModel(b.afficher_id());
       ui->label_16->setText( ui->comboBox_3->currentText());





}


void Dialog2::on_pushButton_4_clicked()
{
    int a=ui->label_11->text().toInt();
    animaux o;
    if(o.supprimer(a)){
        ui->tableView->setModel(o.afficher(this));

    }
     refresh();
}

void Dialog2::on_comboBox_activated(const QString &arg1)
{
    ui->label_11->setText(arg1);
}

void Dialog2::on_comboBox_2_activated(const QString &arg1)
{
    ui->label_12->setText(arg1);
}

void Dialog2::on_pushButton_6_clicked()
{
    animaux a;
     if(ui->label_12->text()=="trie par masse"){

         ui->tableView->setModel(a.trier_masse());
     }
     if(ui->label_12->text()=="trie par prix"){

         ui->tableView->setModel(a.trier_prix());
     }
}

void Dialog2::on_tableView_activated(const QModelIndex &index)
{
    Delegate *d= new Delegate();
    QWidget * e=d->create(ui->tableView);
    d->set(e,index);
    QString a=d->setmodel(e,ui->tableView->model(),index);

int col=index.row();
int col1=index.column();
 QModelIndex b=ui->tableView->model()->index(col,0,QModelIndex());
 QVariant f=b.data(Qt::DisplayRole);
 /*ui->label_15->setText(f.toString());
 ui->label_17->setNum(col1);
 ui->label_18->setNum(col);*/
 if(col1==1){
     QSqlQuery q;
     q.prepare("update animaux set nom = ? where id = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("nom modifie .\n"));
      }

 }
if(col1==2){
     QSqlQuery q;
     q.prepare("update animaux set prix = ? where id = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("prix modifie .\n"));
      }

 }
if(col1==3){
     QSqlQuery q;
     q.prepare("update animaux set masse = ? where id = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("masse modifie .\n"));
      }

 }
}

void Dialog2::on_pushButton_3_clicked()
{
    int id = ui->label_13->text().toInt();
     QString culture= ui->lineEdit_3->text();
        int prix= ui->lineEdit_6->text().toInt();

          int masse= ui->lineEdit_7->text().toInt();
         animaux f;
         bool test=f.modifier(id,culture,prix,masse);
       if(test)
         {
            ui->tableView->setModel((f.afficher(this)));//refresh
            QMessageBox::information(nullptr, QObject::tr("Modifier un animal !"),
                              QObject::tr(" animal modifié ! \n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
         }

         else {

             QMessageBox::critical(nullptr, QObject::tr("Modifier un animal"),
                         QObject::tr("Erreur !.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);
         }
       refresh();

}

class PrintBorde : public PagePrepare
{
public:
    virtual void preparePage(QPainter *painter);
    static int pageNumber;
};

int PrintBorde::pageNumber = 0;

void PrintBorde::preparePage(QPainter *painter)
{ // print a border on each page
    QRect rec = painter->viewport();
    painter->setPen(QPen(QColor(0, 0, 0), 1));
    painter->drawRect(rec);
    painter->translate(10, painter->viewport().height() - 10);
    painter->drawText(0, 0, QString("Page %1").arg(pageNumber));
    pageNumber += 1;
}
void Dialog2::uglyPrint(QPrinter *printer) {

    // ---------------- death-to-designers example ------------------

    QPainter uglyPainter;
    if(!uglyPainter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    TablePrinter uglyTablePrinter(&uglyPainter, printer);
    QVector<int> colStretch = QVector<int>() << 5 << 5 << 5 << 10;
    uglyTablePrinter.setPen(QPen(QColor(0, 100, 255), 3, Qt::DotLine)); // pen for borders
    uglyTablePrinter.setHeaderColor(Qt::red);
    uglyTablePrinter.setContentColor(Qt::green);
    QFont font1; // font for headers
    font1.setBold(true);
    QFont font2; // font for content
    font2.setItalic(true);
    uglyTablePrinter.setHeadersFont(font1);
    uglyTablePrinter.setContentFont(font2);
    PrintBorde *printB = new PrintBorde;
    printB->pageNumber = 1;
    uglyTablePrinter.setPagePrepare(printB);
    QVector<QString> headers = QVector<QString>() << "ID" << "CULTURE" << "SURFACE"<< "TYPEA" ;
    uglyPainter.setPen(QPen(Qt::yellow));
    uglyPainter.drawText(uglyPainter.viewport().width()/2 - 40, 40, "TABLE plantes");
    uglyPainter.translate(0, 60); // start print point
    uglyTablePrinter.setCellMargin(10, 5, 5);
    uglyTablePrinter.setPageMargin(100, 40, 40);
    if(!uglyTablePrinter.printTable(ui->tableView->model(), colStretch, headers)) {
        qDebug() << uglyTablePrinter.lastError();
    }
    uglyPainter.end();
    delete printB;
}

/*void Dialog2::on_pushButton_5_clicked()
{

}*/

void Dialog2::print(QPrinter *printer)  {

    // ------------------ simplest example --------------------------

    QPainter painter;
    if(!painter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    // print table
    TablePrinter tablePrinter(&painter, printer);
    QVector<int> columnStretch = QVector<int>() << 2 << 5  << 15;
    if(!tablePrinter.printTable(ui->tableView->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    painter.end();
}


void Dialog2::print_two_tables(QPrinter *printer) {

    // ------------------ two tables example --------------------------

    QPainter painter;
    if(!painter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    // print table
    TablePrinter tablePrinter(&painter, printer);
    QVector<int> columnStretch = QVector<int>() << 2 << 2 << 5 << 15;
    if(!tablePrinter.printTable(ui->tableView->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    // print second table
    painter.translate(0, 100);
    if(!tablePrinter.printTable(ui->tableView->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    painter.end();
}

void Dialog2::on_pushButton_7_clicked()
{
    QPrintPreviewDialog dialog;
    connect(&dialog, SIGNAL(paintRequested(QPrinter*)), this, SLOT(uglyPrint(QPrinter*)));
    dialog.exec();
}

void Dialog2::on_pushButton_5_clicked()
{
    animaux tmpanimaux;
    int id = ui->lineEdit_4->text().toInt();
   ui->tableView->setModel(tmpanimaux.rechercher(id));
}


void Dialog2::on_pushButton_8_clicked()
{
    int id =ui->lineEdit_5->text().toInt();
        QString nom=ui->lineEdit_9->text();



        int quantite =ui->lineEdit_10->text().toInt();

        nourriture c(id,nom,quantite);
        bool test=c.ajouter();
        if(test)
        {ui->tableView->setModel(c.afficher(this));
        QMessageBox::information(nullptr,QObject::tr("Ajouter un nourriture"),QObject::tr("nourriture ajouter.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);}
        ui->lineEdit_5->clear();
        ui->lineEdit_9->clear();



        ui->lineEdit_10->clear();
        refresh();

}

void Dialog2::on_comboBox_3_activated(const QString &arg1)
{
    ui->label_16->setText(arg1);

}

void Dialog2::on_pushButton_11_clicked()
{
    int a=ui->label_16->text().toInt();
    nourriture o;
    if(o.supprimer(a)){
        ui->tableView_2->setModel(o.afficher(this));

    }
     refresh();

}

void Dialog2::on_tableView_2_activated(const QModelIndex &index)
{
    /*int a=ui->tableView_2->model()->data(index).toInt();
ui->label_15->setNum(a);
    QSqlQuery q;
    q.prepare("select * from nourriture where id = ?;");
     q.addBindValue(a);
     if(q.exec()){
         while(q.next()){
             ui->lineEdit_5->setText(q.value(0).toString());
             ui->lineEdit_9->setText(q.value(1).toString());
             ui->lineEdit_10->setText(q.value(2).toString());





         }
     }
     */
    Delegate *d= new Delegate();
    QWidget * e=d->create(ui->tableView_2);
    d->set(e,index);
    QString a=d->setmodel(e,ui->tableView_2->model(),index);

int col=index.row();
int col1=index.column();
 QModelIndex b=ui->tableView_2->model()->index(col,0,QModelIndex());
 QVariant f=b.data(Qt::DisplayRole);
 ui->label_15->setText(f.toString());
 ui->label_17->setNum(col1);
 ui->label_18->setNum(col);
 if(col1==1){
     QSqlQuery q;
     q.prepare("update nourriture set nom = ? where id = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("nom modifie .\n"));
      }

 }
if(col1==2){
     QSqlQuery q;
     q.prepare("update nourriture set QUANTITE = ? where id = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("quatite modifie .\n"));
      }

 }
 /*if(col1==3){
     QSqlQuery q;
     q.prepare("update mycrud set email = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("email modifie .\n"));
      }

 }
 if(col1==4){
     QSqlQuery q;
     q.prepare("update mycrud set numtel = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("numero de telephone modifie .\n"));
      }

 }
 if(col1==5){
     QSqlQuery q;
     q.prepare("update mycrud set salaire = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("salaire modifie .\n"));
      }

 }*/
     refresh();



}

void Dialog2::on_pushButton_10_clicked()
{
    int id = ui->label_15->text().toInt();
     QString nom= ui->lineEdit_9->text();


          int quantite= ui->lineEdit_10->text().toInt();
         nourriture f;
         bool test=f.modifier(id,nom,quantite);
       if(test)
         {
            ui->tableView_2->setModel((f.afficher(this)));//refresh
            QMessageBox::information(nullptr, QObject::tr("Modifier une nourriture !"),
                              QObject::tr(" nourriture modifié ! \n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
         }

         else {

             QMessageBox::critical(nullptr, QObject::tr("Modifier une nourriture"),
                         QObject::tr("Erreur !.\n"
                                     "Click Cancel to exit."), QMessageBox::Cancel);
         }
           refresh();

}

void Dialog2::on_pushButton_13_clicked()
{
    nourriture tmpnourriture;
    ui->tableView_2->setModel(tmpnourriture.trier_quantite());
}

void Dialog2::on_pushButton_12_clicked()
{
    int id = ui->lineEdit_11->text().toInt();
    nourriture tmpnourriture;
   ui->tableView_2->setModel(tmpnourriture.rechercher(id));
}
void Dialog2::print1(QPrinter *printer)  {

    // ------------------ simplest example --------------------------

    QPainter painter;
    if(!painter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    // print table
    TablePrinter tablePrinter(&painter, printer);
    QVector<int> columnStretch = QVector<int>() << 2 << 5  << 15;
    if(!tablePrinter.printTable(ui->tableView_2->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    painter.end();
}


void Dialog2::print_two_tables1(QPrinter *printer) {

    // ------------------ two tables example --------------------------

    QPainter painter;
    if(!painter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    // print table
    TablePrinter tablePrinter(&painter, printer);
    QVector<int> columnStretch = QVector<int>() << 2 << 2 << 5 << 15;
    if(!tablePrinter.printTable(ui->tableView_2->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    // print second table
    painter.translate(0, 100);
    if(!tablePrinter.printTable(ui->tableView_2->model(), columnStretch)) {
        qDebug() << tablePrinter.lastError();
    }
    painter.end();
}

void Dialog2::uglyPrint1(QPrinter *printer) {

    // ---------------- death-to-designers example ------------------

    QPainter uglyPainter;
    if(!uglyPainter.begin(printer)) {
        qWarning() << "can't start printer";
        return;
    }
    TablePrinter uglyTablePrinter(&uglyPainter, printer);
    QVector<int> colStretch = QVector<int>() << 5 << 5 << 5 ;
    uglyTablePrinter.setPen(QPen(QColor(0, 100, 255), 3, Qt::DotLine)); // pen for borders
    uglyTablePrinter.setHeaderColor(Qt::red);
    uglyTablePrinter.setContentColor(Qt::green);
    QFont font1; // font for headers
    font1.setBold(true);
    QFont font2; // font for content
    font2.setItalic(true);
    uglyTablePrinter.setHeadersFont(font1);
    uglyTablePrinter.setContentFont(font2);
    PrintBorde *printB = new PrintBorde;
    printB->pageNumber = 1;
    uglyTablePrinter.setPagePrepare(printB);
    QVector<QString> headers = QVector<QString>() << "ID" << "nom" << "quantite" ;
    uglyPainter.setPen(QPen(Qt::blue));
    uglyPainter.drawText(uglyPainter.viewport().width()/2 - 40, 40, "TABLE nourriture");
    uglyPainter.translate(0, 60); // start print point
    uglyTablePrinter.setCellMargin(10, 5, 5);
    uglyTablePrinter.setPageMargin(100, 40, 40);
    if(!uglyTablePrinter.printTable(ui->tableView_2->model(), colStretch, headers)) {
        qDebug() << uglyTablePrinter.lastError();
    }
    uglyPainter.end();
    delete printB;
}

void Dialog2::on_pushButton_14_clicked()
{
    QPrintPreviewDialog dialog;
    connect(&dialog, SIGNAL(paintRequested(QPrinter*)), this, SLOT(uglyPrint1(QPrinter*)));
    dialog.exec();
}

/*void Dialog2::on_pushButton_15_clicked()
{
    int id =ui->lineEdit_5->text().toInt();
        QString nom=ui->lineEdit_9->text();



        int quantite =ui->lineEdit_10->text().toInt();

        nourriture c(id,nom,quantite);
        bool test=c.ajouter();
        if(test)
        {ui->tableView->setModel(c.afficher());
        QMessageBox::information(nullptr,QObject::tr("Ajouter un nourriture"),QObject::tr("nourriture ajouter.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);}
        ui->lineEdit_5->clear();
        ui->lineEdit_9->clear();



        ui->lineEdit_10->clear();
        refresh();


}*/
