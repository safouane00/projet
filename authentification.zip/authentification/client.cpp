#include "client.h"
#include "clients.h"
#include "ui_client.h"
#include "clients.h"
#include "delegate.h"
#include "fournisseur.h"
#include <QMessageBox>
#include "smtp.h"
#include <QRegExpValidator>
#define email_rx "^[0-9a-zA-Z]+([0-9a-zA-Z]*[-._+])*[0-9a-zA-Z]+@[0-9a-zA-Z]+([-.][0-9a-zA-Z]+)*([0-9a-zA-Z]*[.])[a-zA-Z]{2,6}$"
#define nom_rx "^([A-Za-z])+$"
client::client(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::client)
{
    ui->setupUi(this);
    fournisseur f;
    ui->comboBox->setModel(f.afficher_cin());
      ui->label_11->setNum(ui->comboBox->currentText().toInt());
    ui->tableView->setModel(f.afficher(this));
    clients c;
    ui->comboBox_3->setModel(c.afficher_cin());
      ui->label_19->setNum(ui->comboBox_3->currentText().toInt());
    ui->tableView_3->setModel(c.afficher(this));
     connect(ui->pushButton_13, SIGNAL(clicked()),this, SLOT(sendMail()));
     ui->lineEdit_2->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_7->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_13->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_17->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_18->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_19->setValidator( new QIntValidator(0, 99999999, this) );
     ui->lineEdit_2->setMaxLength(8);
     ui->lineEdit_7->setMaxLength(8);
     QRegExp email(email_rx),nom(nom_rx);
     QRegExpValidator *valid_e=new QRegExpValidator(email,this);
      QRegExpValidator *valid_n=new QRegExpValidator(nom,this);
     ui->lineEdit_5->setValidator(valid_e);
      ui->lineEdit_16->setValidator(valid_e);
     ui->lineEdit_3->setValidator(valid_n);
     ui->lineEdit_4->setValidator(valid_n);
     ui->lineEdit_14->setValidator(valid_n);
     ui->lineEdit_15->setValidator(valid_n);
}

client::~client()
{
    delete ui;
}
void client::sendMail()
{
    Smtp* smtp = new Smtp(ui->lineEdit_9->text(), ui->lineEdit_10->text(), ui->lineEdit->text(), ui->lineEdit_8->text().toInt());
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail(ui->lineEdit_9->text(), ui->lineEdit_20->text() , ui->lineEdit_11->text(),ui->lineEdit_12->text());
}
void client::mailSent(QString status)
{
    if(status == "Message sent")
        QMessageBox::information( 0, tr( "Qt Simple SMTP client" ), tr( "Message sent!\n\n" ) );
}
void client::refresh(){


    fournisseur f;
    ui->label_11->setNum(ui->comboBox->currentText().toInt());
    ui->comboBox->setModel(f.afficher_cin());
    ui->tableView->setModel(f.afficher(this));


}
void client::refresh_2(){


    clients c;
    ui->comboBox_3->setModel(c.afficher_cin());
      ui->label_19->setNum(ui->comboBox_3->currentText().toInt());
    ui->tableView_3->setModel(c.afficher(this));


}

void client::on_pushButton_clicked()
{
    QRegularExpression email(email_rx);
    QRegularExpressionMatch match=email.match(ui->lineEdit_5->text());
    if(!match.hasMatch()){
        QMessageBox::critical(nullptr, QObject::tr("ajout insuccessful"),
                    QObject::tr("invalid email.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else{

        int a= ui->lineEdit_2->text().toInt();
        QString b= ui->lineEdit_3->text();
        QString c= ui->lineEdit_4->text();
        QString d= ui->lineEdit_5->text();
        int e= ui->lineEdit_7->text().toInt();

        fournisseur o(b,c,a,d,e);
        if(o.ajouter()){

            QMessageBox::information(nullptr, QObject::tr("ajout successful"),
                        QObject::tr("ajout successful.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

            refresh();




        }

    }


}

void client::on_comboBox_activated(const QString &arg1)
{
    ui->label_11->setNum(arg1.toInt());
}

void client::on_pushButton_4_clicked()
{
    int idp = ui->label_11->text().toInt();
    fournisseur c;
    bool test=c.supprimer(idp);
    if(test)
    {ui->tableView->setModel(c.afficher(this));
        QMessageBox::information(nullptr,QObject::tr("Supprime une plante"),QObject::tr("plante supprimer.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);}
    refresh();
}

void client::on_tableView_activated(const QModelIndex &index)
{
    Delegate *d= new Delegate();
    QWidget * e=d->create(ui->tableView);
    d->set(e,index);
    QString a=d->setmodel(e,ui->tableView->model(),index);

int col=index.row();
int col1=index.column();
 QModelIndex b=ui->tableView->model()->index(col,2,QModelIndex());
 QVariant f=b.data(Qt::DisplayRole);
 /*ui->label_15->setText(f.toString());
 ui->label_17->setNum(col1);
 ui->label_18->setNum(col);*/
 if(col1==0){
     QSqlQuery q;
     q.prepare("update fournisseur set nom = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("nom modifie .\n"));
      }

 }
if(col1==1){
     QSqlQuery q;
    q.prepare("update fournisseur set prenom = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("prenom modifie .\n"));
      }

 }
if(col1==3){
     QSqlQuery q;
     q.prepare("update fournisseur set mail = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("email modifie .\n"));
      }

 }
if(col1==4){
     QSqlQuery q;
     q.prepare("update FOURNISSEUR set numero = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("numero modifie .\n"));
      }

 }
if(col1==5){
     QSqlQuery q;
     q.prepare("update client set NOMBRE_ARTICLE = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("NOMBRE_ARTICLE modifie .\n"));
      }

 }
if(col1==6){
     QSqlQuery q;
     q.prepare("update client set SOMME_PAYER = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("SOMME_PAYER modifie .\n"));
      }

 }
}

void client::on_pushButton_3_clicked()
{
    int id = ui->label_12->text().toInt();
    QString nom=ui->lineEdit_3->text();
    QString prenom=ui->lineEdit_4->text();
    int cinn =ui->lineEdit_2->text().toInt();
    QString mail =ui->lineEdit_5->text();
    int numero =ui->lineEdit_7->text().toInt();

    fournisseur c(nom,prenom,cinn,mail,numero);
    bool test=c.modifier(id);
    if(test)
    {
    QMessageBox::information(nullptr,QObject::tr("modifier un fournisseur"),QObject::tr("fournisseur modifier.\n"
                                                                                    "Click Cancel to exit."), QMessageBox::Cancel);}
    else
    {
        QMessageBox::information(nullptr,QObject::tr("modifier un fournisseur"),QObject::tr("erreur modifier.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);
    }
    refresh();
}

void client::on_pushButton_9_clicked()
{
    int a= ui->lineEdit_13->text().toInt();
    QString b= ui->lineEdit_14->text();
    QString c= ui->lineEdit_15->text();
    QString d= ui->lineEdit_16->text();
    int e= ui->lineEdit_17->text().toInt();
    int f= ui->lineEdit_18->text().toInt();
    int g = ui->lineEdit_19->text().toInt();

    clients o(b,c,a,d,e,f,g);
    if(o.ajouter()){

        QMessageBox::information(nullptr, QObject::tr("ajout successful"),
                    QObject::tr("ajout successful.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

        refresh_2();
    }

}

void client::on_pushButton_12_clicked()
{
    int idp = ui->label_19->text().toInt();
    clients c;
    bool test=c.supprimer(idp);
    if(test)
    {ui->tableView_3->setModel(c.afficher(this));
        QMessageBox::information(nullptr,QObject::tr("Supprime une plante"),QObject::tr("plante supprimer.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);}
    refresh_2();

}

void client::on_tableView_3_activated(const QModelIndex &index)
{
    Delegate *d= new Delegate();
    QWidget * e=d->create(ui->tableView_3);
    d->set(e,index);
    QString a=d->setmodel(e,ui->tableView_3->model(),index);

int col=index.row();
int col1=index.column();
 QModelIndex b=ui->tableView_3->model()->index(col,2,QModelIndex());
 QVariant f=b.data(Qt::DisplayRole);
 /*ui->label_15->setText(f.toString());
 ui->label_17->setNum(col1);
 ui->label_18->setNum(col);*/
 if(col1==0){
     QSqlQuery q;
     q.prepare("update client set nom = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("nom modifie .\n"));
      }

 }
if(col1==1){
     QSqlQuery q;
    q.prepare("update client set prenom = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("prenom modifie .\n"));
      }

 }
if(col1==3){
     QSqlQuery q;
     q.prepare("update client set mail = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("email modifie .\n"));
      }

 }
if(col1==4){
     QSqlQuery q;
     q.prepare("update client set numero = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("numero modifie .\n"));
      }

 }
if(col1==5){
     QSqlQuery q;
     q.prepare("update client set NOMBRE_ARTICLE = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("NOMBRE_ARTICLE modifie .\n"));
      }

 }
if(col1==6){
     QSqlQuery q;
     q.prepare("update client set SOMME_PAYER = ? where cin = ?;");
      q.addBindValue(a);
      q.addBindValue(f);
      if(q.exec()){
          QMessageBox::information(this, tr("ligne modifie"), tr("SOMME_PAYER modifie .\n"));
      }

 }


}

void client::on_pushButton_11_clicked()
{
    int id = ui->label_20->text().toInt();
    QString nom=ui->lineEdit_14->text();
    QString prenom=ui->lineEdit_15->text();
    int cinn =ui->lineEdit_13->text().toInt();
    QString mail =ui->lineEdit_16->text();
    int numero =ui->lineEdit_17->text().toInt();
    int a =ui->lineEdit_18->text().toInt();
    int b =ui->lineEdit_19->text().toInt();

    clients c(nom,prenom,cinn,mail,numero,a,b);
    bool test=c.modifier(id);
    if(test)
    {
    QMessageBox::information(nullptr,QObject::tr("modifier un client"),QObject::tr("client modifier.\n"
                                                                                    "Click Cancel to exit."), QMessageBox::Cancel);}
    else
    {
        QMessageBox::information(nullptr,QObject::tr("modifier un client"),QObject::tr("erreur modifier.\n"
                                                                                        "Click Cancel to exit."), QMessageBox::Cancel);
    }
    refresh_2();

}

void client::on_comboBox_3_activated(const QString &arg1)
{
     ui->label_19->setNum(arg1.toInt());
}
