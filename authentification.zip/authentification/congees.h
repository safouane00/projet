#ifndef CONGEES_H
#define CONGEES_H


class congees
{
public:
    congees();
};

#endif // CONGEES_H
