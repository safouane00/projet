#ifndef DIALOG2_H
#define DIALOG2_H
#include "tableprinter.h"
#include <QDialog>
#include <QMessageBox>


#include "tableprinter.h"
#include <QPrinter>
#include <QPrintPreviewDialog>
#include <QPainter>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlTableModel>

#include <QDialog>

namespace Ui {
class Dialog2;
}

class Dialog2 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog2(QWidget *parent = nullptr);
    ~Dialog2();

    void refresh();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

    void on_comboBox_activated(const QString &arg1);

    void on_comboBox_2_activated(const QString &arg1);

    void on_pushButton_6_clicked();
    void print(QPrinter *printer);
    void print_two_tables(QPrinter *printer);
     void uglyPrint(QPrinter *printer);
     void print1(QPrinter *printer);
     void print_two_tables1(QPrinter *printer);
      void uglyPrint1(QPrinter *printer);

    void on_tableView_activated(const QModelIndex &index);

    void on_pushButton_3_clicked();



    void on_pushButton_7_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_8_clicked();

    void on_comboBox_3_activated(const QString &arg1);

    void on_pushButton_11_clicked();

    void on_tableView_2_activated(const QModelIndex &index);

    void on_pushButton_10_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_14_clicked();

    //void on_pushButton_15_clicked();

private:
    Ui::Dialog2 *ui;
};

#endif // DIALOG2_H
