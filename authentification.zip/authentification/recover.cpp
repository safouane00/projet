#include "recover.h"
#include "smtp.h"
#include "ui_recover.h"
#include<QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QPixmap>
#include <QLabel>

#include <QMovie>

recover::recover(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::recover)
{
    ui->setupUi(this);
}
void recover::delay()
{
    QTime dieTime= QTime::currentTime().addSecs(10);
    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

recover::~recover()
{
    delete ui;
}

void recover::on_pushButton_3_clicked()
{
    int a=ui->lineEdit->text().toInt();
    QSqlQuery query;
    QString test_id,email,mdp;
    query.prepare("select * from admin where id=?");
    query.addBindValue(a);
    query.exec();
    while(query.next()){
        test_id=query.value(0).toString();
    email=query.value(3).toString();
    mdp=query.value(4).toString();

    }
    Smtp* smtp = new Smtp("ala.romdhani@esprit.tn", "181JMT1740", "smtp.gmail.com", 465);
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));


    smtp->sendMail("ala.romdhani@esprit.tn", email, "mode passe recovery","votre mot de passe est "+mdp);
    QLabel* label=new QLabel();
    label->setWindowFlag(Qt::FramelessWindowHint);
    //label->setMask((new QPixmap("C:/Users/hp/Documents/splash/spec splashscreen/farm.gif"))->mask(this));
    QMovie* movie=new QMovie("C:/Users/hp/Documents/splash/spec splashscreen/farm.gif");

    label->setMovie(movie);
    movie->start();
    label->show();
   delay();
    movie->stop() ;
    label->close();



}
