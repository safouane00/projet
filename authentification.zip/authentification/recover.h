#ifndef RECOVER_H
#define RECOVER_H

#include <QDialog>

namespace Ui {
class recover;
}

class recover : public QDialog
{
    Q_OBJECT

public:
    explicit recover(QWidget *parent = nullptr);
    ~recover();
void delay();
private slots:
    void on_pushButton_3_clicked();

private:
    Ui::recover *ui;
};

#endif // RECOVER_H
