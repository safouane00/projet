#include "produitch.h"

chimie::chimie()
{
    nom="";
    marque="";
    id_ch=0;
    prix="";
    quantit="";
}
QStandardItemModel* chimie::afficher(QObject* parent){


    QSqlQuery q;
    q.prepare("select * from chimie;");
     int i=0;
     if(q.exec()){
         while(q.next()){
             for(int col=0; col<5 ; col++){
                 QString a=q.value(i).toString();

             }



             i++;
         }
     }

      QStandardItemModel* model =new QStandardItemModel(i,5,parent);
  // QSqlQueryModel *model1=new QSqlQueryModel();

    //QStandardItemModel* model =new QStandardItemModel(4,2,this);

    q.prepare("select * from chimie;");
     i=0;
     if(q.exec()){
         while(q.next()){
             for(int col=0; col<5 ; col++){
                 QString a=q.value(col).toString();
                 QModelIndex index=model->index(i,col,QModelIndex());
                 model->setData(index,a);
             }



             i++;
         }

     }
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("nom"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("marque"));


    model->setHeaderData(2, Qt::Horizontal, QObject::tr("id"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("prix"));
      model->setHeaderData(4, Qt::Horizontal, QObject::tr("quantite"));
   return model;



}

QStandardItemModel* chimie::chercher(QObject* parent,int a){


    QSqlQuery q;
    q.prepare("select * from chimie where id_ch=?;");
    q.addBindValue(a);
     int i=0;
     if(q.exec()){
         while(q.next()){
             for(int col=0; col<5 ; col++){
                 QString a=q.value(i).toString();

             }



             i++;
         }
     }

      QStandardItemModel* model =new QStandardItemModel(i,5,parent);
  // QSqlQueryModel *model1=new QSqlQueryModel();

    //QStandardItemModel* model =new QStandardItemModel(4,2,this);

    q.prepare("select * from chimie where id_ch=?");
     q.addBindValue(a);
     i=0;
     if(q.exec()){
         while(q.next()){
             for(int col=0; col<6 ; col++){
                 QString a=q.value(col).toString();
                 QModelIndex index=model->index(i,col,QModelIndex());
                 model->setData(index,a);
             }



             i++;
         }
     }
   return model;



}

chimie::chimie(QString nom,QString marque,int id_ch,QString prix,QString  quantit)
{
    this->nom=nom;
    this->marque=marque;
    this->id_ch=id_ch;
    this->quantit=quantit;
    this->prix=prix;
}
QSqlQueryModel * chimie::trier()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select * from chimie ORDER BY prix");

     return model;
}

QString chimie::get_nom(){return nom;}
QString chimie::get_marque(){return marque;}
int chimie::get_id_ch(){return id_ch;}
QString chimie::get_quantit(){return quantit;}
QString  chimie::get_prix(){return prix;}


bool chimie::ajouter()
{
    QSqlQuery query;


    query.prepare("INSERT INTO chimie (nom, marque, id_ch, prix, quantit) "
                          " VALUES (:nom, :marque, :id_ch, :prix, :quantit)" );

    query.addBindValue( nom);
    query.addBindValue( marque);
    query.addBindValue( id_ch);
   query.addBindValue( prix);
    query.addBindValue( quantit);
    return  query.exec();

}



bool chimie::supprimer(int idd)
{
    QSqlQuery query;
    QString res= QString::number(idd);
    query.prepare("Delete from chimie where id_ch = :id_ch");
    query.bindValue(":id_ch", res);
    return  query.exec();
}
bool chimie::modifier(int idd)
{
    QSqlQuery query;
    query.prepare("update chimie set nom = ? , marque = ? , prix = ? , quantit = ? where id_ch = ?");

    query.addBindValue(nom);
    query.addBindValue(marque);
     query.addBindValue(prix);
     query.addBindValue(quantit);


   query.addBindValue(idd);


   return query.exec();

}


QSqlQueryModel * chimie::afficher_id()
{QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("select id_ch from chimie");


    return model;
}

